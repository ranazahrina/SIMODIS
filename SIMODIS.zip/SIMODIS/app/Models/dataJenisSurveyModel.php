<?php

namespace App\Models;

use CodeIgniter\Model;

class dataJenisSurveyModel extends Model
{
    protected $table = 'jenis_survey';
    protected $allowedFields = ['jenis_survey'];
}
